-- Adminer 4.8.1 MySQL 5.7.40 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `buildings`;
CREATE TABLE `buildings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_iso2_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `buildings` (`id`, `name`, `country_iso2_code`, `created_at`, `updated_at`) VALUES
(1,	'Isaac Newton',	'UK',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43'),
(2,	'Oscar Wilde',	'UK',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43'),
(3,	'Charles Darwin',	'UK',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43'),
(4,	'Benjamin Franklin',	'US',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43'),
(5,	'Luciano Pavarotti',	'IT',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43');

DROP TABLE IF EXISTS `building_departments`;
CREATE TABLE `building_departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `building_id` bigint(20) unsigned NOT NULL,
  `department_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `building_departments_building_id_foreign` (`building_id`),
  KEY `building_departments_department_id_foreign` (`department_id`),
  CONSTRAINT `building_departments_building_id_foreign` FOREIGN KEY (`building_id`) REFERENCES `buildings` (`id`),
  CONSTRAINT `building_departments_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `building_departments` (`id`, `building_id`, `department_id`) VALUES
(1,	1,	2),
(2,	2,	3),
(3,	2,	1),
(4,	3,	4),
(5,	4,	2),
(6,	4,	1),
(7,	5,	2),
(8,	5,	1);

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `departments_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `departments` (`id`, `name`, `code`, `created_at`, `updated_at`) VALUES
(1,	'Sales',	'sales',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43'),
(2,	'Development',	'development',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43'),
(3,	'HR',	'hr',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43'),
(4,	'Headquarters',	'headquarters',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43');

DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rfid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_email_unique` (`email`),
  UNIQUE KEY `employees_rfid_unique` (`rfid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `employees` (`id`, `first_name`, `last_name`, `email`, `rfid`, `created_at`, `updated_at`) VALUES
(1,	'Nayden',	'Panchev',	'email@email.com',	'2a73fa6c5694e9b91c3f258a9d01e174',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43'),
(2,	'Georgi',	'Panchev',	'email2@email2.com',	'd6a20f339c9bdbc4db46bde34eca36fa',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43'),
(3,	'Dora',	'Pancheva',	'email3@email3.com',	'ab626c68d5f2510396dfd4090fcffa47',	'2023-05-29 10:39:43',	'2023-05-29 10:39:43');

DROP TABLE IF EXISTS `employee_departments`;
CREATE TABLE `employee_departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) unsigned NOT NULL,
  `department_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_departments_employee_id_foreign` (`employee_id`),
  KEY `employee_departments_department_id_foreign` (`department_id`),
  CONSTRAINT `employee_departments_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `employee_departments_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `employee_departments` (`id`, `employee_id`, `department_id`) VALUES
(1,	1,	2),
(2,	2,	1),
(3,	2,	3);

-- 2023-05-29 12:48:04
